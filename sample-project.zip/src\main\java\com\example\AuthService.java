package com.example;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * AuthService handles authentication using a simple token-based mechanism.
 * Tokens are Base64-encoded and stored in memory with expiry timestamps.
 */
public class AuthService {
    private final UserRepository userRepository;
    private final Map<String, Long> tokenStore = new HashMap<>(); // token -> userId
    private static final long TOKEN_TTL_MS = 3600_000; // 1 hour

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public String login(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
        // NOTE: demo only — real apps must hash passwords
        String token = Base64.getEncoder().encodeToString(
                (email + ":" + System.currentTimeMillis()).getBytes());
        tokenStore.put(token, user.getId());
        return token;
    }

    public User authenticate(String token) {
        Long userId = tokenStore.get(token);
        if (userId == null) throw new SecurityException("Invalid or expired token");
        return userRepository.findById(userId)
                .orElseThrow(() -> new SecurityException("User not found for token"));
    }

    public void logout(String token) {
        tokenStore.remove(token);
    }
}
