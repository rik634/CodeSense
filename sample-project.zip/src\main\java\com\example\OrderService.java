package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * OrderService manages order creation and retrieval.
 * Each order belongs to a user and contains a list of item names with a total price.
 */
public class OrderService {
    private final Map<Long, List<String>> ordersByUser = new HashMap<>();
    private final UserService userService;

    public OrderService(UserService userService) {
        this.userService = userService;
    }

    public void placeOrder(Long userId, List<String> items) {
        userService.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one item");
        }
        ordersByUser.computeIfAbsent(userId, k -> new ArrayList<>()).addAll(items);
    }

    public List<String> getOrders(Long userId) {
        return ordersByUser.getOrDefault(userId, List.of());
    }

    public void cancelOrders(Long userId) {
        ordersByUser.remove(userId);
    }
}
