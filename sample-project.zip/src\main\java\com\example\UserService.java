package com.example;

import java.util.Optional;

/**
 * UserService handles business logic for user management.
 * Supports create, lookup, and delete operations.
 */
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User createUser(Long id, String email, String name, String role) {
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Email must not be blank");
        }
        userRepository.findByEmail(email).ifPresent(u -> {
            throw new IllegalStateException("User with email already exists: " + email);
        });
        return userRepository.save(new User(id, email, name, role));
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public void deleteUser(Long id) {
        userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + id));
        userRepository.deleteById(id);
    }
}
